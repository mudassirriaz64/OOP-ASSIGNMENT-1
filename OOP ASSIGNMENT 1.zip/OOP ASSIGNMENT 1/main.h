#pragma once
#ifndef MAIN_H
#define MAIN_H

#include<iostream>
#include "student.h"
#include "teacher.h"
#include "section.h"
#include"data_handler.h"


#endif
